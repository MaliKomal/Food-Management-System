const express = require("express");
const router = express.Router();
const {
  getAllFarmer,
  addFarmer,
  updateFarmer,
  deleteFarmer,
  searchByIdFarmer,
  getFarmerById,
} = require("../controller/farmer");
const auth = require("../middlewer/auth");
// framer routes

//get  retrive all farmer data
router.get("/farmer/getData/", auth, getAllFarmer);
router.get("/farmer/getById/:id", auth, getFarmerById);
// Route to add farmer data (requires authentication)
router.post("/farmer/addData", auth, addFarmer);
// Route to update farmer data by ID (requires authentication)
router.patch("/farmer/updateData/:id", auth, updateFarmer);
// Route to delete farmer data by ID (requires authentication)
router.delete("/farmer/deleteData/:id", auth, deleteFarmer);
// Route to seacrch farmer data by ID (requires authentication)
router.get("/farmer/search/:id", auth, searchByIdFarmer);

module.exports = router;
