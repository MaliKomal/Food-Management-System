const express = require("express");
const router = express.Router();
const {
  getAllProduct,
  getProductById,
  addProduct,
  updateProduct,
  deleteProduct,
  searchProduct,
} = require("../controller/product");
//this is middleware to chcek admin is auothorized or not
const auth = require("../middlewer/auth");

// Route to get product data
router.get("/product/getData", auth, getAllProduct);
// Route to get product  by iddata (requires authentication)
router.get("/product/getById/:id", auth, getProductById);
// Route to add product data (requires authentication)
router.post("/product/addData", auth, addProduct);
// Route to update product data by ID (requires authentication)
router.patch("/product/updateData/:id", auth, updateProduct);
// Route to delete product data by ID (requires authentication)
router.delete("/product/deleteData/:id", auth, deleteProduct);
// Route to delete product data by ID (requires authentication)
router.get("/product/findData/:id", searchProduct);

module.exports = router;
