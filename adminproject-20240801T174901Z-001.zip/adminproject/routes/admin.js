const express = require("express");
const router = express.Router();
const {
  login,
  getadmin,
  addAdmin,
  updateAdmin,
  deleteAdmin,
} = require("../controller/admin");
const auth = require("../middlewer/auth");

// Route to handle admin login
router.post("/admin/login", login);
// Route to get admin data
router.get("/admin/getData", getadmin);
// Route to add admin data (requires authentication)
router.post("/admin/addData", auth, addAdmin);
// Route to update admin data by ID (requires authentication)
router.patch("/admin/updateData/:id", auth, updateAdmin);
// Route to delete admin data by ID (requires authentication)
router.delete("/admin/deleteData/:id", auth, deleteAdmin);

module.exports = router;
