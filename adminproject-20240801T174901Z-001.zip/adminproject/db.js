require("dotenv").config();
const mysql = require("mysql");

// create database connection
const db = mysql.createConnection({
  host: process.env.database_host,
  user: process.env.database_user,
  password: process.env.database_password,
  database: process.env.database,
});

db.connect((err) => {
  if(err){ 
    console.log("error",err)
    throw err
  }
 
  console.log("Connected Succesfully!");
});

module.exports = db;
