require("dotenv").config();
const jwt = require("jsonwebtoken");
const secretkey = process.env.SECRET_KEY;

const auth = (req, res, next) => {
  const bearerHeader = req.headers["authorization"];

  if (typeof bearerHeader !== "undefined") {
    // console.log("Authorization Header:", bearerHeader); // Log the Authorization header

    const bearer = bearerHeader.split(" ");
    if (bearer.length !== 2) {
      return res
        .status(400)
        .json({ error: "Invalid Authorization header format" });
    }

    const token = bearer[1];
    req.token = token;

    jwt.verify(req.token, secretkey, (error, authData) => {
      if (error) {
        console.error("Token verification error:", error); // Log the error
        return res.status(403).json({ error: "Token is not valid" });
      } else {
        req.authData = authData;
        next();
      }
    });
  } else {
    return res.status(403).json({ message: "Token is required" });
  }
};

module.exports = auth;
