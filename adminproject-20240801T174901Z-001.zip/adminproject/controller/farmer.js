const db = require("../db");
// const body = require("express-validator");
//getAllFarmer fuction used to retrive data from databases.
const getAllFarmer = (req, res) => {
  const sql =
    "select id,name,email,mobile_no,birth_date,address,gender from farmer_register";

  db.query(sql, (error, result) => {
    if (error) {
      return res.status(400).json({ error: error });
    } else {
      return res.status(200).json({ result });
    }
  });
};

const getFarmerById = (req, res) => {
  const farmerId = req.params.id;

  // SQL query to fetch farmer details by ID
  const sql = `
    SELECT id, name, email, mobile_no, birth_date, address, gender 
    FROM farmer_register 
    WHERE id = ?
  `;

  // Execute the query
  db.query(sql, farmerId, (error, result) => {
    if (error) {
      return res.status(400).json({ error: error.message });
    } else {
      if (result.length === 0) {
        return res.status(404).json({ error: "Farmer not found" });
      }
      return res.status(200).json({ farmer: result[0] });
    }
  });
};

/*addFarmer function to add new framer details.Take data from request body like name,email,mobile_no, birth_date, 
address, gender .if block check all feild from request body and using sql cmd insert into database.
If error occure then it display server error otherwise.*/

const addFarmer = (req, res) => {
  const { name, email, mobile_no, birth_date, address, gender } = req.body;
  if (!name || !email || !mobile_no || !birth_date || !address || !gender) {
    return res
      .status(400)
      .json({ error: "email and mobile_no are required..!" });
  } else {
    const cmd =
      "insert into farmer_register(name,email,mobile_no,birth_date,address,gender)values(?,?,?,?,?,?)";

    db.query(
      cmd,
      [name, email, mobile_no, birth_date, address, gender],
      (err, result) => {
        if (err) {
          return res.status(500).json({ error: err });
        } else {
          let insertedId = result.insertId;
          let selectQuery =
            "select id,name,email,mobile_no,birth_date,address,gender from farmer_register where id =?";
          db.query(selectQuery, [insertedId], (err, rows) => {
            if (err) {
              return res.status(500).json({ error: err });
            }
            return res.status(201).json({
              message: "Farmer inserted successfully...!!",
              data: rows[0],
            });
          });
        }
      }
    );
  }
};

/*updateFarmer function  used to update product details.It will take id from url,it aslo take data from request 
body which we want to update.It will update farmer details*/

const updateFarmer = (req, res) => {
  const eid = req.params.id;
  const updatedData = req.body;
  const sql = "update farmer_register set ? where id = ? ";
  db.query(sql, [updatedData, eid], (err, result) => {
    if (err) {
      res.status(500).json({ error: err });
    } else {
      let cmd =
        "select id,name,email,mobile_no,birth_date,address,gender from farmer_register where id =?";
      db.query(cmd, [eid], (err, rows) => {
        if (err) {
          return res.status(500).json({ error: err });
        }
        return res
          .status(201)
          .json({ message: "Data updated sucessfully", data: rows[0] });
      });
    }
  });
};

/*DeleteFarmer fucntion use to delete specific farmer record.So take id from url and check if farmer record present in our 
database if present then delete,if  not then it display record not present*/

const deleteFarmer = (req, res) => {
  const id = req.params.id;
  const cmd = "delete from farmer_register where id = ? ";
  db.query(cmd, [id], (err, result) => {
    if (err) {
      return res.status(404).json({ error: "Farmer record not present." });
    } else {
      return res.status(201).json({ message: "Farmer deleted sucessfully." });
    }
  });
};

//searchByIdFarmer function take id from url and fetch data.also we can can pass other query parameter and check farmer is presnt or not.
const searchByIdFarmer = (req, res) => {
  const id = req.params.id;

  let sql =
    "select id,name,email,mobile_no,birth_date,address,gender from farmer_register where id=?";
  const queryUlr = [id];
  if (req.query.name) {
    sql = sql + " and name=?";
    queryUlr.push(req.query.name);
  }
  if (req.query.email) {
    sql = sql + " and email=?";
    queryUlr.push(req.query.email);
  }
  if (req.query.mobile_no) {
    sql = sql + " and mobile_no=?";
    queryUlr.push(req.query.mobile_no);
  }
  if (req.query.address) {
    sql = sql + " and address=?";
    queryUlr.push(req.query.address);
  }
  if (req.query.gender) {
    sql = sql + " and gender=?";
    queryUlr.push(req.query.gender);
  }
  if (req.query.address) {
    sql = sql + " and address=?";
    queryUlr.push(req.query.email);
  }
  db.query(sql, queryUlr, (error, result) => {
    if (error) {
      return res
        .status(500)
        .json({ message: "Framer record is not available" });
    } else {
      return res.status(404).json({ result: result });
    }
  });
};

module.exports = {
  getAllFarmer,
  addFarmer,
  updateFarmer,
  deleteFarmer,
  searchByIdFarmer,
  getFarmerById,
};
