const db = require("../db");

//getAllFarmer fuction used to retrive data from databases.
const getAllProduct = (req, res) => {
  const sql =
    "SELECT pro_id, pro_name, type_of_product, quantity, prize, image, description, farmer_id, farmer_name FROM product";
  db.query(sql, (error, result) => {
    if (error) {
      return res.status(400).json({ error: error });
    } else {
      return res.status(200).json({ result });
    }
  });
};

const getProductById = (req, res) => {
  const proId = req.params.id;

  // SQL query to fetch product details by ID
  const sql =
    "SELECT pro_id, pro_name, type_of_product, quantity, prize, image, description, farmer_id, farmer_name FROM product WHERE pro_id = ?";

  // Execute the query
  db.query(sql, proId, (error, result) => {
    if (error) {
      return res.status(400).json({ error: error.message });
    } else {
      if (result.length === 0) {
        return res.status(404).json({ error: "Product not found" });
      }
      return res.status(200).json({ product: result[0] });
    }
  });
};

/*addProduct function to add new product details.Take data from request body like pro_name, type_of_product, quantity, prize,
 image, description.if block check all feild is present or not in requset body, using sql cmd insert data  into database.
If error occure then it display server error otherwise.*/

const addProduct = (req, res) => {
  const {
    pro_name,
    type_of_product,
    quantity,
    prize,
    image,
    description,
    farmer_id,
    farmer_name,
  } = req.body;

  if (
    !pro_name ||
    !type_of_product ||
    !quantity ||
    !prize ||
    !image ||
    !description ||
    farmer_id ||
    farmer_name
  ) {
    return res.status(400).json({ error: "Field are required..!" });
  } else {
    const cmd =
      "insert into product (pro_name,type_of_product,quantity,prize,image,description,farmer_id,farmer_name)values(?,?,?,?,?,?,?,?)";
    db.query(
      cmd,
      [
        pro_name,
        type_of_product,
        quantity,
        prize,
        image,
        description,
        farmer_id,
        farmer_name,
      ],
      (err, result) => {
        if (err) {
          console.log("error", err);
          return res.status(500).json({ error: err });
        } else {
          let insertedId = result.insertId;
          let selectQuery =
            "select pro_id,pro_name,type_of_product,quantity,prize,image,description,farmer_id,farmer_name from product  where pro_id =?";
          db.query(selectQuery, [insertedId], (err, rows) => {
            if (err) {
              return res.status(500).json({ error: err });
            }
            return res.status(201).json({
              message: "Product inserted successfully",
              data: rows[0],
            });
          });
        }
      }
    );
  }
};

/*updateProduct function  used to update product details.It will take id from url,it aslo take data from request 
body which we want to update.It will update product details*/

const updateProduct = (req, res) => {
  const eid = req.params.id;
  const updatedData = req.body;
  const sql = "update product  set ? where pro_id = ? ";
  db.query(sql, [updatedData, eid], (err, result) => {
    if (err) {
      res.status(500).json({ error: err });
    } else {
      let cmd =
        "select pro_id,pro_name,type_of_product,quantity,prize,image,description,farmer_id from product  where pro_id =?";
      db.query(cmd, [eid], (err, rows) => {
        if (err) {
          return res.status(500).json({ error: err });
        }
        return res
          .status(201)
          .json({ message: "Product updated sucessfully", data: rows[0] });
      });
    }
  });
};

/*DeleteAdmin fucntion use to delete specific product record.So take id from url and check if product record present in our 
database if present then it will delete,if  not then it display product not present*/
const deleteProduct = (req, res) => {
  const id = req.params.id;
  const cmd = "delete from product  where pro_id = ? ";
  db.query(cmd, [id], (err, result) => {
    if (err) {
      return res.status(404).json({ error: "Product not present." });
    } else {
      return res.status(201).json({ message: "Product deleted sucessfully" });
    }
  });
};

//searchProduct function serach a specific record.It take data from url and check is match found so it will return record.
const searchProduct = (req, res) => {
  const id = req.params.id;
  let sql =
    "select pro_id,pro_name,type_of_product,quantity,prize,image,description from product where pro_id=?";
  const queryUlr = [id];
  if (req.query.pro_name) {
    sql = sql + " and pro_name=?";
    queryUlr.push(req.query.pro_name);
  }
  if (req.query.type_of_product) {
    sql = sql + " and type_of_product=?";
    queryUlr.push(req.query.type_of_product);
  }
  if (req.query.quantity) {
    sql = sql + " and quantity=?";
    queryUlr.push(req.query.quantity);
  }
  if (req.query.prize) {
    sql = sql + " and prize=?";
    queryUlr.push(req.query.prize);
  }
  if (req.query.image) {
    sql = sql + " and image=?";
    queryUlr.push(req.query.image);
  }
  if (req.query.description) {
    sql = sql + " and description=?";
    queryUlr.push(req.query.description);
  }
  db.query(sql, queryUlr, (error, result) => {
    if (error) {
      return res.status(500).json({ error: error });
    } else {
      return res.status(404).json({ message: "Product is not avilable" });
    }
  });
};

module.exports = {
  getAllProduct,
  addProduct,
  updateProduct,
  deleteProduct,
  searchProduct,
  getProductById,
};
