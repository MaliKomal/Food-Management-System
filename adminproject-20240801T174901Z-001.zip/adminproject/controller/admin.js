require("dotenv").config();
const db = require("../db");
const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const jwt = require("jsonwebtoken");
const crytop = require("crypto");
const secretkey = process.env.SECRET_KEY;

// const secretkey = "key";
app.use(bodyParser.json());

/* admin login function take username & password from requset body .Password is hash password into tbale if username and password i
is presnt.Then it chcek equest body password  and our databases table password is same ,then token will be generated using jwt(jsonwentoken)
otherwise token not created.*/

const login = (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  // Input validation
  if (!username || !password) {
    return res
      .status(400)
      .json({ error: "Username and password are required" });
  }

  // SQL query to check if username is present in the table and select username & password
  const sql = "select username,password from admin where username=?";
  db.query(sql, [username], (error, results) => {
    if (error) {
      return res.status(500).json({ error: "Internal server error" });
    }

    // Check if username exists in the database
    if (results.length === 0) {
      return res.status(401).json({ error: "Invalid username or password" });
    }

    // Compare hashed passwords
    const passwordfromdb = results[0].password;
    const hashPasswordbody = crytop
      .createHash("sha256")
      .update(password)
      .digest("hex");

    // For demonstration purposes, let's assume the password comparison is successful
    if (passwordfromdb === hashPasswordbody) {
      // Generate JWT token
      jwt.sign(
        { username },
        secretkey,
        { expiresIn: "2 days" },
        (err, token) => {
          if (err) {
            return res.status(500).json({ error: "Internal server error" });
          }
          return res.status(200).json({ message: "Login successful", token });
        }
      );
    } else {
      return res.status(401).json({ error: "Invalid username or password" });
    }
  });
};

//getadmin fuction used to retrive data from databases.
const getadmin = (req, res) => {
  const sql = "select id,username,password from admin";
  db.query(sql, (error, result) => {
    if (error) {
      return res.status(400).json({ error: error });
    } else {
      return res.status(200).json({ result });
    }
  });
};
/*addAdmin function to add new admin details.Take data from request body like username,password .if block check all feild from request body and using sql cmd insert into database.
If error occure then it display server error otherwise.*/

const addAdmin = (req, res) => {
  const { username, password } = req.body;
  //
  if (!username || !password) {
    return res
      .status(400)
      .json({ error: "username and password is requird..!" });
  } else {
    const cmd = "insert into admin(username,password)values(?,?)";

    db.query(cmd, [username, password], (err, result) => {
      if (err) {
        return res.status(500).json({ error: err });
      } else {
        let insertedId = result.insertId;
        let selectQuery = "select id,username,password from admin where id =?";
        db.query(selectQuery, [insertedId], (err, rows) => {
          if (err) {
            return res.status(500).json({ error: err });
          }
          return res
            .status(201)
            .json({
              message: "Admin inserted successfully...!",
              data: rows[0],
            });
        });
      }
    });
  }
};

/*updateAdmin function  used to update admin details.It will take id from url,it aslo take data from request 
body which we want to update.It will update farmer details*/
const updateAdmin = (req, res) => {
  const eid = req.params.id;
  const updatedData = req.body;
  const sql = "update admin set ? where id = ? ";
  db.query(sql, [updatedData, eid], (err, message) => {
    if (err) {
      res.status(500).json({ error: err });
    } else {
      let cmd = "select username,password from admin where id =?";
      db.query(cmd, [eid], (err, rows) => {
        if (err) {
          return res.status(500).json({ error: err });
        }
        return res
          .status(201)
          .json({ message: "Login data updated sucessfully", data: rows[0] });
      });
    }
  });
};

/*DeleteAdmin fucntion use to delete specific admin record.So take id from url and check if admin record present in our 
database if present then it will delete,if  not then it display record not present*/
const deleteAdmin = (req, res) => {
  const id = req.params.id;
  const cmd = "delete from admin where id = ? ";
  db.query(cmd, [id], (err, result) => {
    if (err) {
      return res.status(404).json({ error: "Admin  not present" });
    } else {
      return res.status(201).json({ message: "Admin deleted sucessfully" });
    }
  });
};

module.exports = { login, getadmin, addAdmin, updateAdmin, deleteAdmin };
