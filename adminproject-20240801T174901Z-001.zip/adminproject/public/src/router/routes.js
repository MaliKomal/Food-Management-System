import { createWebHistory, createRouter } from "vue-router";

const routes = [
  {
    name: "Login",
    path: "/login",
    component: () => import("../components/viwes/Login.vue"),
  },

  {
    name: "AddFarmer",
    path: "/AddFarmer",
    component: () => import("../components/viwes/AddFarmer.vue"),
    meta: { requiresAuth: true },
  },
  {
    name: "AddProduct",
    path: "/AddProduct",
    component: () => import("../components/viwes/AddProduct.vue"),
    meta: { requiresAuth: true },
  },
  {
    name: "EditFarmer",
    path: "/EditFarmer",
    component: () => import("../components/viwes/EditFarmer.vue"),
    meta: { requiresAuth: true },
  },
  {
    name: "EditProduct",
    path: "/EditProduct",
    component: () => import("../components/viwes/EditProduct.vue"),
    meta: { requiresAuth: true },
  },
  {
    name: "ViewProduct",
    path: "/ViewProduct",
    component: () => import("../components/viwes/ViewProduct.vue"),
    meta: { requiresAuth: true },
  },
  {
    name: "ViewFarmer",
    path: "/ViewFarmer",
    component: () => import("../components/viwes/ViewFarmer.vue"),
    meta: { requiresAuth: true },
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});
router.beforeEach((to, from, next) => {
  // check if the route requires authentication
  if (to.meta.requiresAuth) {
    if (localStorage.getItem("token")) {
      next();
    } else {
      next("/login");
    }
  } else {
    next();
  }
});

export default router;
