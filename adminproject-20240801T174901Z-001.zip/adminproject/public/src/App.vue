<template>
  <router-view></router-view>
  <!-- <gatData></gatData> -->
</template>
<script>
import gatData from "./components/viwes/img.vue";
export default {
  components: {
    gatData,
  },
};
</script>

<style scoped></style>
