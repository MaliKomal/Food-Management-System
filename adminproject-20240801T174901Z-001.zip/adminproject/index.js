require("dotenv").config();
const express = require("express");
const cors = require("cors");
const app = express();
const http = require("http");
const server = http.createServer(app);
const bodyparser = require("body-parser");
const farmer = require("./routes/farmer");
const product = require("./routes/product");
const admin = require("./routes/admin");
const port = process.env.port;
const localhost = "127.0.0.1";
app.use(
  cors({
    origin: "http://localhost:5173",
    methods: ["GET", "POST", "PATCH", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);
app.use(bodyparser.json());
app.use(express.json());
app.use("/api", farmer);
app.use("/api", product);
app.use("/api", admin);

server.listen(port, localhost, () => {
  console.log("your port is http://" + localhost + ":" + port);
});
